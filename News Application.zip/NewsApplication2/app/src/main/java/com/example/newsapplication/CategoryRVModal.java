package com.example.newsapplication;

public class CategoryRVModal {

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getCategoryImageUrl() {
        return CategoryImageUrl;
    }

    public void setCategoryImageUrl(String categoryImageUrl) {
        CategoryImageUrl = categoryImageUrl;
    }

    public CategoryRVModal(String category, String categoryImageUrl) {
        Category = category;
        CategoryImageUrl = categoryImageUrl;
    }

    private String Category;
    private String CategoryImageUrl;
}
