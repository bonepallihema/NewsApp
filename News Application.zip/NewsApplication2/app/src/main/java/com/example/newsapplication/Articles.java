package com.example.newsapplication;

import com.google.gson.annotations.SerializedName;

public class Articles {

    @SerializedName("title")
    private String title;

    @SerializedName("description")
    private String description;

    @SerializedName("link")
    private String url;

    @SerializedName("image_url")
    private String imageUrl;

    @SerializedName("source_id")
    private String source;

    @SerializedName("pubDate")
    private String publishedAt;

    @SerializedName("content")
    private String content;

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getSource() {
        return source;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getContent() {
        return content;
    }
}
