package com.example.newsapplication;

import android.content.Intent;
import android.net.Uri;  // ✅ import this for Uri
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;  // ✅ import this if you’re using Picasso

public class NewsDeatilActivity extends AppCompatActivity {

    String title, desc, content, imageURL, url;
    private TextView titleTV, subDescTV, contentTV;
    private ImageView newsIV;
    private Button readNewsBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_deatil);

        // Get data from Intent
        title = getIntent().getStringExtra("title");
        desc = getIntent().getStringExtra("desc");    // ✅ fixed this line
        content = getIntent().getStringExtra("content");
        imageURL = getIntent().getStringExtra("image");
        url = getIntent().getStringExtra("url");

        // Find views
        titleTV = findViewById(R.id.idTVTitle);
        subDescTV = findViewById(R.id.idTVSubDesc);
        contentTV = findViewById(R.id.idTVContent);
        newsIV = findViewById(R.id.idIVNews);
        readNewsBtn = findViewById(R.id.idBtnReadNews);

        // Set the text and image
        titleTV.setText(title);
        subDescTV.setText(desc);
        contentTV.setText(content);

        // ✅ Make sure you have added the Picasso dependency in your build.gradle
        Picasso.get().load(imageURL).into(newsIV);

        // Set up click listener to open the article URL
        readNewsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);  // ✅ Fixed Intent
                i.setData(Uri.parse(url));                 // ✅ Parse the URL
                startActivity(i);                          // ✅ Properly call startActivity
            }
        });
    }
}
