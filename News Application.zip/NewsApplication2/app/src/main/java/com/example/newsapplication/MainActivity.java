package com.example.newsapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements CategoryRVAdapter.CategoryClickInterface {

    private RecyclerView newsRV, categoryRV;
    private ProgressBar loadingPB;
    private EditText searchET, countryET;
    private Button searchBtn;
    private ArrayList<Articles> articlesArrayList;
    private ArrayList<CategoryRVModal> categoryRVModalArrayList;
    private NewsRVAdapter newsRVAdapter;
    private CategoryRVAdapter categoryRVAdapter;

    private static final String BASE_URL = "https://newsdata.io/";
    private static final String API_KEY = "pub_c32db92161f04dfbb3cde5b830b12b96";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsRV = findViewById(R.id.idRVNews);
        categoryRV = findViewById(R.id.idRVCategories);
        loadingPB = findViewById(R.id.idPBLoading);
        searchET = findViewById(R.id.idETSearch);
        countryET = findViewById(R.id.idETCountry);
        searchBtn = findViewById(R.id.idBtnSearch);

        articlesArrayList = new ArrayList<>();
        categoryRVModalArrayList = new ArrayList<>();

        newsRVAdapter = new NewsRVAdapter(articlesArrayList, this);
        categoryRVAdapter = new CategoryRVAdapter(categoryRVModalArrayList, this, this);

        newsRV.setLayoutManager(new LinearLayoutManager(this));
        newsRV.setAdapter(newsRVAdapter);

        categoryRV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        categoryRV.setAdapter(categoryRVAdapter);

        getCategories();
        getNews("top");

        searchBtn.setOnClickListener(v -> {
            String keyword = searchET.getText().toString().trim();
            String country = countryET.getText().toString().trim().toLowerCase();

            if (!keyword.isEmpty() && !country.isEmpty()) {
                searchNews(keyword, country);
            } else {
                Toast.makeText(MainActivity.this, "Enter both keyword and country code", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getCategories() {
        categoryRVModalArrayList.add(new CategoryRVModal("top", "https://th.bing.com/th/id/OIP.TycD-jxnVGpRdsAVvBjgpQHaGP?rs=1&pid=ImgDetMain\n"));
        categoryRVModalArrayList.add(new CategoryRVModal("technology", "https://www.teahub.io/photos/full/52-522398_3840x2160-computer-information-technology-wallpaper-information-technology-images.jpg\n"));
        categoryRVModalArrayList.add(new CategoryRVModal("sports", "https://th.bing.com/th/id/OIP.X5aw-4fNV1x0iwLlEo7oMQHaFo?rs=1&pid=ImgDetMain\n"));
        categoryRVModalArrayList.add(new CategoryRVModal("business", "https://wallpaperaccess.com/full/656683.jpg\n"));
        categoryRVModalArrayList.add(new CategoryRVModal("entertainment", "https://th.bing.com/th/id/OIP.1Z2QT1zakpV0UEzdZoky5gHaEK?rs=1&pid=ImgDetMain\n"));
        categoryRVModalArrayList.add(new CategoryRVModal("health", "https://th.bing.com/th/id/OIP.M43am8fEkgGDct75ZKgVhQHaFi?rs=1&pid=ImgDetMain\n"));
        categoryRVAdapter.notifyDataSetChanged();
    }

    private void getNews(String category) {
        loadingPB.setVisibility(View.VISIBLE);
        articlesArrayList.clear();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
        Call<NewsModal> call = retrofitAPI.getNews(API_KEY, category);

        call.enqueue(new Callback<NewsModal>() {
            @Override
            public void onResponse(Call<NewsModal> call, Response<NewsModal> response) {
                loadingPB.setVisibility(View.GONE);
                NewsModal modal = response.body();
                if (modal != null && modal.getArticles() != null) {
                    articlesArrayList.addAll(modal.getArticles());
                    newsRVAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "No news found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NewsModal> call, Throwable t) {
                loadingPB.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("API_ERROR", t.toString());
            }
        });
    }

    private void searchNews(String keyword, String country) {
        loadingPB.setVisibility(View.VISIBLE);
        articlesArrayList.clear();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
        Call<NewsModal> call = retrofitAPI.searchNews(API_KEY, keyword, country);

        call.enqueue(new Callback<NewsModal>() {
            @Override
            public void onResponse(Call<NewsModal> call, Response<NewsModal> response) {
                loadingPB.setVisibility(View.GONE);
                NewsModal modal = response.body();
                if (modal != null && modal.getArticles() != null) {
                    articlesArrayList.addAll(modal.getArticles());
                    newsRVAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "No news found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NewsModal> call, Throwable t) {
                loadingPB.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Search failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onCategoryClick(int position) {
        String category = categoryRVModalArrayList.get(position).getCategory();
        getNews(category);
    }
}
