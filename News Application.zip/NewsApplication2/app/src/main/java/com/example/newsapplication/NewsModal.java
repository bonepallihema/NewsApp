package com.example.newsapplication;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;

public class NewsModal {

    @SerializedName("status")
    private String status;

    @SerializedName("totalResults")
    private int totalResults;

    @SerializedName("results")
    private ArrayList<Articles> articles;

    public String getStatus() {
        return status;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public ArrayList<Articles> getArticles() {
        return articles;
    }
}
