package com.example.newsapplication;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class MediastackResponse {
    @SerializedName("data")
    private List<Articles> data;

    public List<Articles> getData() {
        return data;
    }
}
