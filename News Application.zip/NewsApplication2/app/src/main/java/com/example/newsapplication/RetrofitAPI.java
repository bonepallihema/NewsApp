package com.example.newsapplication;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitAPI {

    // 📰 Fetch news by category (used for category clicks)
    @GET("api/1/news")
    Call<NewsModal> getNews(
            @Query("apikey") String apiKey,
            @Query("category") String category
    );

    // 🔍 Search news by keyword and country
    @GET("api/1/news")
    Call<NewsModal> searchNews(
            @Query("apikey") String apiKey,
            @Query("q") String keyword,
            @Query("country") String country
    );
}
